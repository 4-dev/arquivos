package br.com.4dev.orderfood;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderfoodApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderfoodApplication.class, args);
	}
}
